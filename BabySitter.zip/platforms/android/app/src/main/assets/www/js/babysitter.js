function logout() {
    window.location.href = 'index.html';
}

function loadBabysitters() {
    const babysitters = [
        { name: 'Alice Johnson', email: 'alice@example.com', contact: '+123 456 7890', bio: 'Experienced babysitter with 5 years of experience.' },
        { name: 'Bob Smith', email: 'bob@example.com', contact: '+987 654 3210', bio: 'Certified in CPR and First Aid.' },
        { name: 'Charlie Brown', email: 'charlie@example.com', contact: '+456 789 1230', bio: 'Enjoys working with children of all ages.' },
        { name: 'Diana Prince', email: 'diana@example.com', contact: '+321 654 9870', bio: 'Available for night shifts and weekends.' },
        { name: 'Eve Adams', email: 'eve@example.com', contact: '+213 546 8790', bio: 'Loves engaging children in educational activities.' }
    ];

    const babysittersList = document.getElementById('babysittersList');
    babysittersList.innerHTML = '';

    babysitters.forEach(babysitter => {
        const babysitterDiv = document.createElement('div');
        babysitterDiv.classList.add('babysitter-profile');
        babysitterDiv.innerHTML = `
            <h3>${babysitter.name}</h3>
            <p><strong>Email:</strong> ${babysitter.email}</p>
            <p><strong>Contact:</strong> ${babysitter.contact}</p>
            <p class="bio">${babysitter.bio}</p>
        `;
        babysittersList.appendChild(babysitterDiv);
    });
}

if (window.location.pathname.endsWith('babysitter.html')) {
    loadBabysitters();
}

function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = 'index.html'; // Redirect to login page
}

